# General
- SailPoint OOTB DTO classes suck

# Front-End
## modal-search-roles.html
- [ ] The block that says if the search had no results stays shown, however this works in the page.xhtml. But the role object does not seem to be of the type array, so maybe 'length' does not work

# Back-End
## RoleSearcherRest.class
- [ ] Response status is not correctly interpreted in the front end --> not found still gives a 200 statusCode