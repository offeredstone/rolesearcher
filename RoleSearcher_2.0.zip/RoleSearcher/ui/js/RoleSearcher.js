// Define an AngularJS module
var app = angular.module("RoleSearcherAN", ['ngAnimate', 'ui.bootstrap']);

/**
* Service thingie
**/
app.factory('MyService', function ($http) {

    let myService = {};

    myService.searchItRoles = function (savedSearch, page) {
        console.log("In SearchItRoles with search");
        console.log(savedSearch);
        console.log("Requesting page: " + page);
        // Make an HTTP GET request with custom headers
        return $http.get(PluginHelper.getPluginRestUrl('RoleSearcher/getItRoles'), {
            headers: {
                'X-CSRF-Token': PluginHelper.getCsrfToken(),
                'timeout': 3000,
                'searchMethod': savedSearch.type,
                'searchValue': savedSearch.value,
                'searchAppCode': savedSearch.appCode,
                'searchEnvCode': savedSearch.envCode,
                'searchIsOwner': savedSearch.isOwner,
                'page': page
            }
        }).then(function (response) {
            if(response.status !== 200){
                console.error(response.status + " - " + response.statusText);
                return null; 
            }
            console.log(response.data);
            return response.data;
        }).catch(function (error) {
            console.error("Error in fetch " + error);
            return null;
        });
    };

    myService.searchBusinessRoles = function (savedSearch, page) {
        console.log("In SearchBusinessRolesRoles with search");
        console.log(savedSearch);
        console.log("Requesting page: " + page);
        // Make an HTTP GET request with custom headers
        return $http.get(PluginHelper.getPluginRestUrl('RoleSearcher/getBusinessRoles'), {
            headers: {
                'X-CSRF-Token': PluginHelper.getCsrfToken(),
                'timeout': 3000,
                'searchMethod': savedSearch.type,
                'searchValue': savedSearch.value,
                'searchIsOwner': savedSearch.isOwner,
                'page': page
            }
        }).then(function (response) {
            console.log(response.data);
            if(response.status !== 200){
                console.error(response.status + " - " + response.statusText);
                return null; 
            }
            return response.data;
        }).catch(function (error) {
            console.error("Error in fetch " + error);
            return null;
        });
    };

    myService.getRoleById = function (id) {
        console.log("In getRoleById with id: " + id);
        // Make an HTTP GET request with custom headers
        return $http.get(PluginHelper.getPluginRestUrl('RoleSearcher/getBundleById'), {
            headers: {
                'X-CSRF-Token': PluginHelper.getCsrfToken(),
                'timeout': 3000,
                'id': id
            }
        }).then(function (response) {
            console.error(response.status + " - " + response.statusText);

            if(response.status !== 200){
                console.error(response.status + " - " + response.statusText);
                return null; 
            }
            console.log(response.data);
            return response.data;
        }).catch(function (error) {
            console.error("Error in fetch " + error);
            return null;
        });
    };

    myService.fetchAppCodes = function () {
        // Make an HTTP GET request with custom headers
        return $http.get(PluginHelper.getPluginRestUrl('RoleSearcher/getAppCodes'), {
            headers: {
                'X-CSRF-Token': PluginHelper.getCsrfToken()
            }
        }).then(function (response) {
            if(response.status !== 200){
                console.error(response.status + " - " + response.statusText);
                return null; 
            }
            console.log(response.data);
            return response.data;
        }).catch(function (error) {
            console.error("Error in fetch " + error);
            return null;
        });
    };

    myService.fetchEnvironments = function (appCode) {
        // Make an HTTP GET request with custom headers
        return $http.get(PluginHelper.getPluginRestUrl('RoleSearcher/getEnvironmentCodes'), {
            headers: {
                'X-CSRF-Token': PluginHelper.getCsrfToken(),
                'appCode': appCode
            }
        }).then(function (response) {
            if(response.status !== 200){
                console.error(response.status + " - " + response.statusText);
                return null; 
            }
            console.log(response.data);
            return response.data;
        }).catch(function (error) {
            console.error("Error in fetch " + error);
            return null;
        });
    };

    return myService;

});

/**
* CONTROLLER FOR THE SEARCH MODAL
**/
app.controller('RoleSearcherCtrl', function ($scope, $uibModalInstance, roleType, MyService) {

    // Field options
    $scope.fieldOptions = {
        modalTitle: "",
        nameSearch: true,
        appCodeSearch: true,
        ownerSearch: true
    };

    // Variables for search
    $scope.savedSearch = {
        type: "contains",
        value: "",
        appCode: "",
        envCode: "",
        isOwner: false
    };

    // Paginazation options
    $scope.pages = {
        maxSize: 5,
        itemsPerPage: 1,
        totalItems: 1,
        currentPage: 1
    }

    // UI options
    $scope.ui = {
        isLoading: false,
        update: true
    }

    // Variables to store results
    $scope.results = {
        envCodes: [],
        appCodes: [],
        roles: []
    };

    // Selected roles
    $scope.selectedRoles = [];


    // Initialization function
    function init() {
        if (roleType === "it") {
            console.log("Modal type : IT");
            $scope.fieldOptions.modalTitle = "Search for IT Roles";
            $scope.fieldOptions.nameSearch = false;
            $scope.fieldOptions.appCodeSearch = false;
            $scope.fieldOptions.ownerSearch = false;
        } else if (roleType === "business") {
            console.log("Modal type : BUSINESS");
            $scope.fieldOptions.modalTitle = "Search for Business Roles";
            $scope.fieldOptions.nameSearch = false;
            $scope.fieldOptions.ownerSearch = false;
        } else {
            console.log("UNKNOWN ROLE TYPE" + roleType);
            // UNKNOWN ROLE TYPE
        }
        if (!$scope.fieldOptions.appCodeSearch) {
            console.log("Updating application codes");
            let fetchAppCodesPromise = MyService.fetchAppCodes();
            fetchAppCodesPromise.then(function (result) {
                $scope.results.appCodes = result;
            });
        }
        $scope.updateSearch(); // Fill the table with results   
    }

    // Method to update the environments if an appcode is selected
    $scope.updateEnvironmentCodes = function () {
        console.log("Updating environments for appcode: " + $scope.selectedAppCode);
        let fetchEnvCodesPromise = MyService.fetchEnvironments($scope.savedSearch.appCode);
        fetchEnvCodesPromise.then(function (result) {
            $scope.results.envCodes = result;
            console.log("RESULT: " + result);
            $scope.updateSearch();
        });
    }


    // 
    $scope.updateSearch = function () {
        console.log("In updateSearch");
        $scope.ui.update = true;
        if ($scope.ui.isLoading) return "";

        $scope.ui.isLoading = true;
        $scope.ui.update = false;
        if (roleType === "it") {
            console.log("Searching for: IT ROLES");
            let searchRolesPromise = MyService.searchItRoles($scope.savedSearch, $scope.pages.currentPage);
            searchRolesPromise.then(function (result) {
                if (result != null) {
                    // TODO Check if the result is good and valid
                    let rolesWithCheckbox = [];
                    result.result.forEach(element => {
                        let exists = $scope.selectedRoles.some(function (el) {
                            return (el.name === element.name && el.id === element.id);
                        });
                        rolesWithCheckbox.push({ selected: exists });
                    });
                    $scope.results.roles = angular.merge({}, result.result, rolesWithCheckbox);
                    $scope.pages.totalItems = result.totalPages;
                    console.log(result.totalPages);
                    console.log($scope.pages.totalItems);
                    if ($scope.pages.currentPage > $scope.pages.totalItems) {
                        $scope.pages.currentPage = 1;
                    }
                }
                $scope.ui.isLoading = false;
                if ($scope.ui.update) $scope.updateSearch();


            });
        } else if (roleType === "business") {
            console.log("Searching for: BUSINESS ROLES");
            let searchRolesPromise = MyService.searchBusinessRoles($scope.savedSearch, $scope.pages.currentPage);
            searchRolesPromise.then(function (result) {
                if (result != null) {
                    // TODO Check if the result is good and valid
                    let rolesWithCheckbox = [];
                    result.result.forEach(element => {
                        let exists = $scope.selectedRoles.some(function (el) {
                            return (el.name === element.name && el.id === element.id);
                        });
                        rolesWithCheckbox.push({ selected: exists });
                    });
                    $scope.results.roles = angular.merge({}, result.result, rolesWithCheckbox);
                    $scope.pages.totalItems = result.totalPages;
                    console.log(result.totalPages);
                    console.log($scope.pages.totalItems);
                    if ($scope.pages.currentPage > $scope.pages.totalItems) {
                        $scope.pages.currentPage = 1;
                    }
                }
                $scope.ui.isLoading = false;
                if ($scope.ui.update) $scope.updateSearch();


            });
        }

    }

    // Select the checkbox when the table row is clicked
    $scope.rowClicked = function (role) {
        role.selected = !role.selected;
        let indexOfRole = $scope.selectedRoles.indexOf(role);
        if (indexOfRole == -1) {
            console.log("Role was not found");
            $scope.selectedRoles.push(role);
        } else {
            console.log("Role was found");
            $scope.selectedRoles.splice(indexOfRole, 1);
        }
        console.log($scope.selectedRoles);

    };

    // Closes the dialog
    $scope.close = function () {
        $uibModalInstance.dismiss();
    };

    $scope.select = function () {
        console.log("Saved search created: ");
        console.log($scope.savedSearch);
        $uibModalInstance.close($scope.selectedRoles);
    };


    // Call init after view is loaded
    init();

});

/**
* CONTROLLER FOR THE SEARCH MODAL
**/
app.controller('RoleViewerCtrl', function ($scope, $uibModalInstance, role, MyService) {

    $scope.fieldOptions = {
        modalTitle: ""
    };

    $scope.results = {
        fullRole: ""
    }

    // Closes the dialog
    $scope.close = function () {
        $uibModalInstance.dismiss();
    };

    // Initialization function
    function init() {
        if (role !== null && role.type !== null) {
            if (role.type === "it" || role.type === "it_nonrequestable") {
                console.log("Modal type : IT");
                $scope.fieldOptions.modalTitle = "IT Role: " + role.displayName;
            } else if (role.type === "business" || role.type === "business_nonrequestable") {
                console.log("Modal type : BUSINESS");
                $scope.fieldOptions.modalTitle = "Business Role: " + role.displayName;
            } else {
                console.log("UNKNOWN ROLE TYPE" + roleType);
                // UNKNOWN ROLE TYPE
            }

            // Get the full role
            let fetFullRolePromise = MyService.getRoleById(role.id);
            fetFullRolePromise.then(function (result) {
                $scope.results.fullRole = result;
                console.log("RESULT: " + result);
            });

        }
    }

    init();

});

// Define an AngularJS controller
app.controller("RoleController", function ($scope, $http, $uibModal, MyService) {


    $scope.selectedRoles = [];


    $scope.showRoleInfo = function (role) {
        $uibModal.open({
            animation: true,
            size: "lg",
            controller: 'RoleViewerCtrl as ctrl',
            templateUrl: PluginHelper.getPluginFileUrl('RoleSearcher', 'ui/html/roles/modal-view-role.html'),
            resolve: {
                role: function () { return role; }
            }
        });

    }

    $scope.editRole = function (role) {

    }

    $scope.removeRole = function (role) {
        let indexOfRole = $scope.selectedRoles.indexOf(role);
        if (indexOfRole !== -1) {
            $scope.selectedRoles.splice(indexOfRole, 1);
        } else {
            console.error("Role was not found in selectedRoles");
        }
    }

    $scope.selectRoles = function (type) {
        let modalInstance = $uibModal.open({
            animation: true,
            size: "lg",
            controller: 'RoleSearcherCtrl as ctrl',
            templateUrl: PluginHelper.getPluginFileUrl('RoleSearcher', 'ui/html/roles/modal-search-roles.html'),
            resolve: {
                roleType: function () { return type; }
            }
        });

        modalInstance.result.then(function (res) {
            res.forEach(e => { $scope.selectedRoles.push(e) });
        }, function () {
            console.log('Modal dismissed at: ' + new Date());
        });
    };




});
