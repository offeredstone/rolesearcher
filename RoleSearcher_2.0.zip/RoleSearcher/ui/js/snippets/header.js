var url = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=RoleSearcher';
jQuery(document).ready(function(){
    jQuery("ul.navbar-right li:first")
        .before(
            '<li class="dropdown">' +
            '		<a href="' + url + '" tabindex="0" role="menuitem" title="Custom made thingie">' +
            '			Manage Roles' +
            '		</a>' +
            '</li>'
        );
});
