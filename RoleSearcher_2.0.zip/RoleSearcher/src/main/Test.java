package main;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Test {

    private static final Log log = LogFactory.getLog("sailpoint.server.CsrfValidationException");


    public Test(String message){
        log.error("Test Constructor: Message is " + message);
    }

    public Test(){
        log.error("Test Constructor: without the message param");
    }

    public void echoTest(String message){
        log.error("EchoTest: Message is " + message);
    }

    public static void echoTestStatic(String message){
        log.error("echoTestStatic: Message is " + message);
    }

}
