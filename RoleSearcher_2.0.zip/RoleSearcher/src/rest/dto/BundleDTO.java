package rest.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import sailpoint.object.Bundle;
import sailpoint.object.Identity;

public class BundleDTO extends Bundle {

    @JsonIgnore
    @Override
    public Identity getOwner() {
        return super.getOwner();
    }
}
