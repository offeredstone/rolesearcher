package rest.dto;

import sailpoint.object.Attributes;
import sailpoint.object.Bundle;

public class FullBundleDTO {

    private String name;
    private String displayName;
    private String type;
    private Attributes<String, Object> attributes;
    private String[] parentId;
    private String ownerId;
    public FullBundleDTO(Bundle b){
        this.name = b.getName();
        this.displayName = b.getDisplayName();
        this.type = b.getType();
        this.attributes = b.getAttributes();
        this.parentId = (b.getInheritance() == null ? null : (String[]) b.getInheritance().stream().map(e -> e.getId().toString()).toArray());
        this.ownerId = (b.getOwner() == null ? null : b.getOwner().getId());
    }

    public String getName() {
        return name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getType() {
        return type;
    }

    public Attributes<String, Object> getAttributes() {
        return attributes;
    }

    public String[] getParentId() {
        return parentId;
    }

    public String getOwnerId() {
        return ownerId;
    }
}
