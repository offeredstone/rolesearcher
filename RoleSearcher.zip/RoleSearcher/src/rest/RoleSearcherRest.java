package rest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import rest.dto.ShortBundleDTO;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Bundle;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.QueryOptions;
import sailpoint.rest.plugin.AllowAll;
import sailpoint.rest.plugin.BasePluginResource;
import sailpoint.tools.Util;

import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import java.util.*;


@Path("RoleSearcher")
@Produces("application/json")
@Consumes("application/json")
@AllowAll
public class RoleSearcherRest extends BasePluginResource {

    private static final int PAGE_LIMIT = 100;

    private static final Log log = LogFactory.getLog("sailpoint.server.CsrfValidationException");

    @Override
    public String getPluginName() {
        return "RoleSearcher";
    }

    @GET
    @Path("getTest")
    @AllowAll
    @Produces("text/plain")
    public String getTest() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return "This is a test";
    }

    @GET
    @Path("getAppCodes")
    @AllowAll
    @Produces("application/json")
    public Response getAppCodes() {
        log.error("In method getAppCodes");
        try {
            SailPointContext context = SailPointFactory.getCurrentContext();
            QueryOptions qo = new QueryOptions();
            qo.addFilter(Filter.or(Filter.eq("type","PXS-applicationcomponent"), Filter.eq("type","pxs-application")));
            qo.setDistinct(true);

            Iterator iterator = context.search(Bundle.class, qo);

            List<String> result = new ArrayList<>();

            while(iterator != null && iterator.hasNext()){
               Bundle b = (Bundle) iterator.next();
               if(b!= null && b.getAttribute("applicationcode") != null && !result.contains(b.getAttribute("applicationcode"))){
                   result.add(b.getAttribute("applicationcode").toString());
               }
            }
            return Response.ok().entity(result).build();

        } catch (Exception e) {
            log.error("Exception while fetching roles: " + e);
        }
        log.error("Sending 500 error");
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
    }

    @GET
    @Path("getEnvironmentCodes")
    @AllowAll
    @Produces("application/json")
    public Response getEnvironmentCodes(@HeaderParam("appCode") String appCode) {
        log.error("In method getEnvironmentCodes");
        try {
            SailPointContext context = SailPointFactory.getCurrentContext();
            QueryOptions qo = new QueryOptions();
            qo.addFilter(Filter.eq("type","pxs-applicationenvironment"));
            qo.addFilter(Filter.eq("applicationcode", appCode.toUpperCase()));
            qo.setDistinct(true);

            List<String> properties = new ArrayList<>();
            properties.add("environmentcode");

            Iterator iterator = context.search(Bundle.class, qo);

            Map<String, String> result = new HashMap<>();

            while(iterator != null && iterator.hasNext()){
                Bundle envRole = (Bundle) iterator.next();
                String envCode = (String) envRole.getAttribute("environmentcode");
                log.error(envRole.getDisplayName());
                if(main.util.Util.ENVIRONMENT_CODES.containsKey(envCode) && !result.containsKey(envCode)){
                    result.put(envCode, main.util.Util.ENVIRONMENT_CODES.get(envCode));
                }else{
                    log.error("Environment code: " + envCode + " was not found");
                }
            }
            return Response.ok().entity(result).build();

        } catch (Exception e) {
            log.error("Exception while fetching roles: " + e);
        }
        log.error("Sending 500 error");
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
    }

    @GET
    @Path("getRoles")
    @AllowAll
    @Produces("application/json")
    public Response getRoles(@HeaderParam("searchMethod") String searchMethod,
                             @HeaderParam("searchValue") String searchValue,
                             @HeaderParam("searchAppCode") String searchAppCode,
                             @HeaderParam("searchEnvCode") String searchEnvCode,
                             @HeaderParam("searchIsOwner") boolean searchIsOwner,
                             @HeaderParam("page") int page) {
        log.error("In getRoles");

        if (searchMethod == null || searchValue == null)
            return Response.status(Response.Status.NOT_ACCEPTABLE).build(); // Request check
        log.error("search method: " + searchMethod);
        log.error("search value: " + searchValue);
        log.error("search appCode: " + searchAppCode);
        log.error("search envCode: " + searchEnvCode);
        log.error("search isOwner: " + searchIsOwner);

        try {
            SailPointContext context = SailPointFactory.getCurrentContext();
            log.error("Got context");

            // Build the query
            QueryOptions qo = new QueryOptions();
            qo.addFilter(Filter.or(Filter.eq("type", "it_nonrequestable"), Filter.eq("type", "it")));

            if (!"".equalsIgnoreCase(searchValue)) {
                if ("contains".equalsIgnoreCase(searchMethod)) {
                    qo.addFilter(Filter.like("name", searchValue, Filter.MatchMode.ANYWHERE));
                } else if ("ends".equalsIgnoreCase(searchMethod)) {
                    qo.addFilter(Filter.like("name", searchValue, Filter.MatchMode.END));
                } else if ("starts".equalsIgnoreCase(searchMethod)) {
                    qo.addFilter(Filter.like("name", searchValue, Filter.MatchMode.START));
                } else {
                    log.error("Search method not accepted: " + searchMethod);
                    return Response.status(Response.Status.NOT_ACCEPTABLE).build();
                }
            }

            if(!"".equals(searchAppCode)){
                qo.addFilter(Filter.eq("applicationcode", searchAppCode));

                if(!"".equals(searchEnvCode)){
                    qo.addFilter(Filter.eq("environmentcode", searchEnvCode));
                }
            }

            if(searchIsOwner){
                log.error("Adding queryOptions to only show user managed roles for user: " + context.getUserName());
                Identity theUser = context.getObjectByName(Identity.class, context.getUserName());
                if(theUser != null){
                    qo.setScopeResults(true);
                    qo.addOwnerScope(theUser);
                    for(Filter f : qo.getScopeExtensions()){
                        qo.addFilter(f);
                    }
                }else{
                    log.error("User was not found... Unable to limit scope");
                }

            }


            qo.setResultLimit(PAGE_LIMIT);
            qo.setFirstRow(PAGE_LIMIT * page);


            // End of building query

            int amountOfBundles = context.countObjects(Bundle.class, qo);
            Iterator iterator = context.search(Bundle.class, qo);
            List<ShortBundleDTO> result = new ArrayList<>();

            log.error("Searched roles");
            int c = 0;
            while (iterator != null && iterator.hasNext()) {
                log.error("In loop: " + c);
                c++;
                Bundle b = (Bundle) iterator.next();
                if (b != null) {
                    result.add(new ShortBundleDTO(b.getId(), b.getName(), b.getDisplayName()));
                }
            }
            log.error("Flushing iterator");
            Util.flushIterator(iterator);
            log.error("Building response");
            Map<String, Object> resultRequest = new HashMap<>();
            resultRequest.put("result", result);
            resultRequest.put("total", Math.ceil(amountOfBundles / PAGE_LIMIT));
            log.error("Sending response");

            return Response.ok().entity(resultRequest).build();

        } catch (Exception e) {
            log.error("Exception while fetching roles: " + e);
        }
        log.error("Sending 500 error");
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
    }


}
