package main.util;

import java.util.HashMap;
import java.util.Map;

public class Util {

    public static final Map<String, String> ENVIRONMENT_CODES;

    static {
        ENVIRONMENT_CODES = new HashMap<>();
        ENVIRONMENT_CODES.put("ACC","Acceptance - ACC (User Acceptance Tests)");
        ENVIRONMENT_CODES.put("ACC2","Acceptance - ACC2 (Parallel User Acceptance Tests)");
        ENVIRONMENT_CODES.put("FDB","Acceptance - FDB (Pre-release testing of database scripts)");
        ENVIRONMENT_CODES.put("GHOST","Acceptance - GHOST (Data staging, extraction and manipulation)");
        ENVIRONMENT_CODES.put("PSU","Acceptance - PSU (Production Support: emergency bugfixes, reference data acceptance tests)");
        ENVIRONMENT_CODES.put("QDB","Acceptance - QDB (Reporting: daily data copy of production)");
        ENVIRONMENT_CODES.put("TRN","Acceptance - TRN (Training)");
        ENVIRONMENT_CODES.put("DEV","Development - DEV (Software Build by application team, default)");
        ENVIRONMENT_CODES.put("DEV2","Development - DEV2 (Software Build by application team, optional)");
        ENVIRONMENT_CODES.put("DEV3","Development - DEV3 (Massive development, not integrated)");
        ENVIRONMENT_CODES.put("TMP","Development - TMP (Temp VDB environment for developers)");
        ENVIRONMENT_CODES.put("VANILLA","Development - VANILLA (Out of the box external software)");
        ENVIRONMENT_CODES.put("VD1","Development - VD1 (Vendor Development Environment 1)");
        ENVIRONMENT_CODES.put("VD2","Development - VD2 (Vendor Development Environment 2)");
        ENVIRONMENT_CODES.put("BKUP","Production - BKUP (Backup Hot and Warm)");
        ENVIRONMENT_CODES.put("BKUP1","Production - BKUP1 (Backup Cold)");
        ENVIRONMENT_CODES.put("OBS","Production - OBS (Operation Business Support)");
        ENVIRONMENT_CODES.put("PRD","Production - PRD (Production)");
        ENVIRONMENT_CODES.put("INT","Testing - INT (Integration tests)");
        ENVIRONMENT_CODES.put("INT2","Testing - INT2 (Parallel Integration tests)");
        ENVIRONMENT_CODES.put("MASS","Testing - MASS (Massive events: load, performance and stress tests)");
        ENVIRONMENT_CODES.put("SYS","Testing - SYS (System tests, not integrated)");
    }

}
