// Define an AngularJS module
var app = angular.module("RoleSearcherAN", ['ngAnimate', 'ui.bootstrap']);

/**
* Service thingie
**/
app.factory('MyService', function ($http) {

    let myService = {};

    myService.searchRoles = function (savedSearch, page) {
        console.log("In SearchRoles with search");
        console.log(savedSearch);
        console.log("Requesting page: " + page);
        // Make an HTTP GET request with custom headers
        return $http.get(PluginHelper.getPluginRestUrl('RoleSearcher/getRoles'), {
            headers: {
                'X-CSRF-Token': PluginHelper.getCsrfToken(),
                'searchMethod': savedSearch.type,
                'searchValue': savedSearch.value,
                'searchAppCode': savedSearch.appCode,
                'searchEnvCode': savedSearch.envCode,
                'searchIsOwner': savedSearch.isOwner,
                'page': page
            }
        }).then(function (response) {
            console.log(response.data);
            return response.data;
        }).catch(function (error) {
            console.error("Error in fetch " + error);
            return null;
        });
    };

    myService.fetchAppCodes = function () {
        // Make an HTTP GET request with custom headers
        return $http.get(PluginHelper.getPluginRestUrl('RoleSearcher/getAppCodes'), {
            headers: {
                'X-CSRF-Token': PluginHelper.getCsrfToken()
            }
        }).then(function (response) {
            console.log(response.data);
            return response.data;
        }).catch(function (error) {
            console.error("Error in fetch " + error);
            return null;
        });
    };

    myService.fetchEnvironments = function (appCode) {
        // Make an HTTP GET request with custom headers
        return $http.get(PluginHelper.getPluginRestUrl('RoleSearcher/getEnvironmentCodes'), {
            headers: {
                'X-CSRF-Token': PluginHelper.getCsrfToken(),
                'appCode': appCode
            }
        }).then(function (response) {
            console.log(response.data);
            return response.data;
        }).catch(function (error) {
            console.error("Error in fetch " + error);
            return null;
        });
    };

    return myService;

});


/**
* The controller for the modal where the search parameter can be set
*/
app.controller('ItRoleSearcherCtrl', function ($scope, $uibModalInstance, test, MyService) {
    console.log("In ItRoleSearcherCtrl");
    // Variables for search
    $scope.savedSearch = {
        type: "contains",
        value: "",
        appCode: "",
        envCode: "",
        isOwner: false
    };

    $scope.echoObject = function () {
        console.log($scope.savedSearch);
    }



    /*
    $scope.radioModel = "contains";
    $scope.searchValue = "";
    $scope.selectedAppCode = "No application code selected";
    $scope.selectedEnvCode = "No environment code selected";
    $scope.isOwner = false;*/

    // Variables to store results
    $scope.envCodes = [];
    $scope.appCodes = [];


    // Method that is called when the controller is loaded
    $scope.init = function () {
        console.log("In init");
        let fetchAppCodesPromise = MyService.fetchAppCodes();
        fetchAppCodesPromise.then(function (result) {
            $scope.appCodes = result;
        });
    }


    // Method to update the environments if an appcode is selected
    $scope.updateEnvironmentCodes = function () {
        console.log("Updating environments for appcode: " + $scope.selectedAppCode);
        let fetchEnvCodesPromise = MyService.fetchEnvironments($scope.savedSearch.appCode);
        fetchEnvCodesPromise.then(function (result) {
            $scope.envCodes = result;
            console.log("RESULT: " + result);
        });
    }


    $scope.test = test;

    /**
     * Closes the dialog.
     */
    $scope.close = function () {
        $uibModalInstance.dismiss();
    };

    $scope.search = function () {
        console.log("Saved search created: ");
        console.log($scope.savedSearch);
        $uibModalInstance.close($scope.savedSearch);
    };

    $scope.init();

});

/**
* The controller for the modal where the roles can be selected
*/
app.controller('ItRoleSelectorCtrl', function ($scope, $uibModalInstance, savedSearch, roles, totalPages, MyService) {
    console.log("In ItRoleSelectorCtrl");
    console.log(roles);
    console.log(totalPages);
    $scope.roles = roles;

    $scope.maxSize = 5;
    $scope.itemsPerPage = 1;
    $scope.totalItems = totalPages;
    $scope.currentPage = 1;

    $scope.isLoading = false;

    $scope.savedSearch = savedSearch;

    $scope.pageChanged = function () {
        console.log("eefeff");
        $scope.isLoading = true;
        let searchRolesPromise = MyService.searchRoles($scope.savedSearch, $scope.currentPage);
        searchRolesPromise.then(function (result) {
            $scope.roles = result.result;
            $scope.isLoading = false;
        });
    };

    /**
     * Closes the dialog.
     */
    $scope.close = function () {
        $uibModalInstance.dismiss();
    };

    $scope.ok = function () {
        $uibModalInstance.close({
            savedSearch: $scope.savedSearch,
            roles: $scope.roles
        });
    };

});

// Define an AngularJS controller
app.controller("RoleController", function ($scope, $http, $uibModal, MyService) {


    $scope.savedSearch = {};

    $scope.foundRoles = [];

    $scope.page = 1;

    $scope.openModal = function () {
        let modalInstance = $uibModal.open({
            animation: true,
            size: "lg",
            controller: 'ItRoleSearcherCtrl as ctrl',
            templateUrl: PluginHelper.getPluginFileUrl('RoleSearcher', 'ui/html/modal-itRoles.html'),
            resolve: {
                test: function () {
                    return "test";
                }
            }
        });

        modalInstance.result.then(function (res) {
            console.log("Search Modal closed, result =>");
            console.log(res);
            $scope.savedSearch = res;
            let searchRolesPromise = MyService.searchRoles($scope.savedSearch, $scope.page);
            searchRolesPromise.then(function (result) {
                console.log("RESULT: " + result.result);
                console.log(result);
                openSecondModal(result);
            });
        }, function () {
            console.log('Modal dismissed at: ' + new Date());
        });
    };


    function openSecondModal(res) {
        console.log("OPENING SECOND MODAL");
        let secondModalInstance = $uibModal.open({
            animation: true,
            size: "lg",
            controller: 'ItRoleSelectorCtrl as ctrl',
            templateUrl: PluginHelper.getPluginFileUrl('RoleSearcher', 'ui/html/modal-itRoles-Selector.html'),
            resolve: {
                'roles': function () {
                    return res.result;
                },
                'totalPages': function () {
                    return res.total;
                },
                'savedSearch': $scope.savedSearch
            }
        });

        secondModalInstance.result.then(function (res) {
            $scope.savedSearch = res.savedSearch;
            res.roles.forEach(element => {
                console.log(element.name);
            });
        }, function () {
            console.log('Modal dismissed at: ' + new Date());
        });
    };


});
